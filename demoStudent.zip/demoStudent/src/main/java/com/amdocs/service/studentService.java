package com.amdocs.service;

import java.util.List;

import com.amdocs.entity.student;

public interface studentService {
	public student saveStudent(student stud);
	
	public List<student> getAllStudents();
	
}
