package com.amdocs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amdocs.entity.student;
import com.amdocs.repo.studentrepojava;
@Service
public class StudentserviceI implements studentService {
@Autowired
private studentrepojava studentRepo;
	public StudentserviceI(studentrepojava studentRepo) {
	
	this.studentRepo = studentRepo;
}

	@Override
	public student saveStudent(student stud) {
		// TODO Auto-generated method stub
		return studentRepo.save(stud);
	}

	@Override
	public List<student> getAllStudents() {
		// TODO Auto-generated method stub
		return studentRepo.findAll();
	}

}
